package com.BootMVC.BootRegistration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootRegistrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
