package com.BootMVC.BootRegistration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootRegistrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootRegistrationApplication.class, args);
	}
}
