package com.BootMVC.BootRegistration;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import jakarta.validation.Valid;

@Controller
public class RegisterController {
	
	private List<User> userList = new ArrayList<>();

	@GetMapping("/adduser")
    public String showAddUserForm(Model model) {
        model.addAttribute("user", new User());
        return "add-user";
    }

    @PostMapping("/adduser")
    public String addUser(@ModelAttribute("user") @Valid User user, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return "add-user";
        }
        
        // Simulate saving the user (replace this with your actual logic)
        userList.add(user);
        
        return "redirect:/userlist"; // Redirect to the user list page
    }

    @GetMapping("/userlist")
    public String showUserList(Model model) {
        // You can replace this list with your actual user data retrieval logic
        model.addAttribute("users", userList);

        return "user-list"; // Replace with the name of your user list HTML file
    }
	@RequestMapping(value = "/register", method = RequestMethod.GET)

	public String viewRegistration(Map<String, Object> model) {
		User userForm = new User();
		model.put("userForm", userForm);
		/*
		 * //spring.thymeleaf.cache: false
		 * 
		 * 
		 * spring.mvc.view.prefix: /WEB-INF/views/
		 *  spring.mvc.view.suffix: .jsp
		 */
		List<String> professionList = new ArrayList<>();
		professionList.add("Developer");
		professionList.add("Designer");
		professionList.add("IT Manager");
		model.put("professionList", professionList);

		return "Registration";
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String processRegistration(@Valid @ModelAttribute("userForm") User user, BindingResult bindingResult,
			Map<String, Object> model) {

		// implement your own registration logic here...

		// for testing purpose:
		System.out.println("username: " + user.getName());
		System.out.println("password: " + user.getPassword());
		System.out.println("email: " + user.getEmail());
		System.out.println("birth date: " + user.getBirthday());

		if (bindingResult.hasErrors()) {
			System.out.println(bindingResult.getAllErrors());
			return "Registration";
		} else {
			return "RegistrationSuccess";
		}

	}
}
